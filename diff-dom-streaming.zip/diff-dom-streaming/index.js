const http = require("http");
const path = require("path");
const fs = require("fs").promises;

const names = {
  "/foo": "Foo",
  "/bar": "Bar",
};

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const name = names[url.pathname] ?? "Hello, World";

  if (url.pathname === "/code") {
    try {
      const filePath = path.join(__dirname, "code.js");
      const file = await fs.readFile(filePath);
      res.writeHead(200, { "Content-Type": "application/javascript" });
      res.end(file);
    } catch (err) {
      res.writeHead(500);
      res.end("Error loading file");
    }
    return;
  }

  if (url.pathname === "/script-test.js") {
    try {
      const filePath = path.join(__dirname, "script-test.js");
      const file = await fs.readFile(filePath);
      res.writeHead(200, { "Content-Type": "application/javascript" });
      res.end(file);
    } catch (err) {
      res.writeHead(500);
      res.end("Error loading file");
    }
    return;
  }

  if (url.pathname === "/style.css") {
    try {
      const filePath = path.join(__dirname, "style.css");
      const file = await fs.readFile(filePath);
      res.writeHead(200, { "Content-Type": "text/css" });
      res.end(file);
    } catch (err) {
      res.writeHead(500);
      res.end("Error loading file");
    }
    return;
  }

  res.writeHead(200, { "Content-Type": "text/html" });
  res.write(`
    <html>
      <head>
        <title>SPA-like navigation with Diff DOM Streaming ${name}</title>
        <link rel="stylesheet" href="style.css"></link>
      </head>
      <body>
        <nav>
          <a href="/">Home</a>
          <a href="/foo">Foo</a>
          <a href="/bar">Bar</a>
        </nav>
        <h1>${name}!</h1>
        <counter-component></counter-component>
        <script>console.log('${name}')</script>
        <script src="/script-test.js"></script>
        <script src="/code"></script>
      </body>
    </html>
  `);

  // Add "Suspense" placeholder
  // res.write('<div id="suspense">Loading...</div>');

  // // Simulate expensive operation
  // setTimeout(() => {
  // res.write(`
  //     <template id="suspensed-content"><div>Expensive content</div></template>
  //   `);
  // res.write(`
  //     <script>
  //       async function unsuspense() {
  //         const suspensedElement = document.getElementById('suspense');
  //         const suspensedTemplate = document.getElementById('suspensed-content');
  //         if (suspensedElement && suspensedTemplate) {
  //           document.startViewTransition(() => {
  //             suspensedElement.replaceWith(suspensedTemplate.content.cloneNode(true));
  //             suspensedTemplate.remove();
  //           });
  //         }
  //       }
  //       unsuspense();
  //     </script>
  //   `);
  // res.write(`
  //     <counter-component></counter-component>
  //     <script>console.log('${name}')</script>
  //     <script src="/script-test.js"></script>
  //     <script src="/code"></script>
  //   `);
  res.end();
  // }, 2000);
});

server.listen(3333, () => {
  console.log(`Done! http://localhost:3333`);
});
